package config

/*	Desarrollo	*/
var CadenaConexionBDEvaluaciones = "sqlserver://app_4dxtablero:app_4dxtablero@des-cobbe01:1433?database=BPEvaluaciones"
var CadenaConexionBDEO = "sqlserver://app_4dxtablero:app_4dxtablero@des-cobbe01:1433?database=EstructuraOrganizacional"
var RutaCertificado = ""
var RutaCertificadoKey = ""

/*	Pruebas */
// var CadenaConexionBDEvaluaciones = "sqlserver://app_4dxtablero:app_4dxtablero@des-cobbe01:1433?database=BPEvaluaciones"
// var CadenaConexionBDEO = "sqlserver://app_BPEvaluaciones:Bp3v@Lu8c1oN3$@pu-aplicabe04:1433?database=BPEvaluaciones"
// var RutaCertificado = "/etc/ssl/BPevaluaciones/servicioevaluacionespu.banpais.hn.cer"
// var RutaCertificadoKey = "/etc/ssl/BPevaluaciones/servicioevaluacionespu.banpais.hn.key"

/*	Produccion */
// var CadenaConexionBDEvaluaciones = "sqlserver://app_BPEvaluaciones:Bp3v@Lu8c1oN3$@PRD-APLICABE04:1433?database=BPEvaluaciones"
// var CadenaConexionBDEO = "sqlserver://app_BPEvaluaciones:Bp3v@Lu8c1oN3$@PRD-APLICABE04:1433?database=BPEvaluaciones"
// var RutaCertificado = "/etc/ssl/BPevaluaciones/servicioevaluaciones.banpais.hn.cer"
// var RutaCertificadoKey = "/etc/ssl/BPevaluaciones/servicioevaluaciones.banpais.hn.key"
